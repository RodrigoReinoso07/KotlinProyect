package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import io.ktor.client.HttpClient
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.request.get
import io.ktor.http.URLProtocol
import kotlinx.coroutines.DelicateCoroutinesApi
import retrofit2.Retrofit


@JsonClass(generateAdapter = true)
data class Character(
    val id: Int,
    val name: String,
    val title: String,
    val family: String,
    val imageUrl: String
)

/*class Characters : AppCompatActivity() {
    private val client = HttpClient {
        install(JsonFeature) {
            kotlinx.serialization.json.Json {
                ignoreUnknownKeys = true
            }
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_characters)

        GlobalScope.launch(Dispatchers.IO) {
            try {
                val characters = client.get<List<Character>> {
                    url {
                        protocol = URLProtocol.HTTPS
                        host = "thronesapi.com"
                        encodedPath = "/api/v2/Characters"
                        Log.d("mensj", "llamado")
                    }

                }

                runOnUiThread {
                    val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
                    val adapter = CustomAdapter(characters)

                    recyclerView.layoutManager = LinearLayoutManager(this@Characters)
                    recyclerView.adapter = adapter
                    Log.d("mensj", "adapter")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}*/

class Characters : AppCompatActivity() {
    object RetrofitClient{
        private val baseURL = "https://jsopnplaceholder.typicode.com"
        private val moshi = Moshi.Builder()
            .addLast(CustomAdapter())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(baseURL)
            .addConverterFactory(MoshiConvertFactory.create(moshi))
            .build()
    }
}


class CustomAdapter(private val characters: List<Character>) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context).inflate(R.layout.card_layout, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val character = characters[i]
        viewHolder.itemNombre.text = characters[i].name
        viewHolder.itemId.text = character.id.toString()
        viewHolder.itemTitle.text = character.title
        viewHolder.itemFamily.text = character.family
        Picasso.get().load(character.imageUrl).into(viewHolder.itemImage)
    }

    override fun getItemCount(): Int {
        return characters.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView
        var itemNombre: TextView
        var itemId: TextView
        var itemTitle: TextView
        var itemFamily: TextView

        init {
            itemImage = itemView.findViewById(R.id.item_image)
            itemNombre = itemView.findViewById(R.id.item_nombre)
            itemId = itemView.findViewById(R.id.item_id)
            itemTitle = itemView.findViewById(R.id.item_title)
            itemFamily = itemView.findViewById(R.id.item_family)
        }

    }
}




