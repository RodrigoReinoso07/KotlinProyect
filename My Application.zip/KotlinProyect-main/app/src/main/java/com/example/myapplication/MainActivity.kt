package com.example.myapplication
import android.content.Context
import android.content.Intent
import androidx.room.Room
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.content.SharedPreferences
import android.widget.CheckBox

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var emailEditText: EditText
    private lateinit var claveEditText: EditText
    private lateinit var dbUsuarios: DBUsuarios



    override fun onCreate(savedInstanceState: Bundle?) {
        sharedPreferences = getSharedPreferences("Recordar_Usuario", Context.MODE_PRIVATE)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEditText =findViewById(R.id.txtCorreoElectronico)
        claveEditText =findViewById(R.id.txtClave)
        dbUsuarios=DBUsuarios.getDatabase(this)


        var btnCrearCuenta = findViewById<Button>(R.id.btnCrearCuenta)
        var btnIniciarSesion = findViewById<Button>(R.id.btnInciarSesion)
        val checkBoxRecordarUsuario = findViewById<CheckBox>(R.id.cbRecordarUsuario)

        val recordarUsuario = sharedPreferences.getBoolean("recordar_usuario", false)
        checkBoxRecordarUsuario.isChecked = recordarUsuario
        if (recordarUsuario && sharedPreferences.getString("Usuario","") !== ""){
            val usuario = sharedPreferences.getString("Usuario","")
            val clave = sharedPreferences.getString("Clave","")
            findViewById<EditText>(R.id.txtCorreoElectronico).setText(usuario.toString())
            findViewById<EditText>(R.id.txtClave).setText(clave.toString())
        }


        btnCrearCuenta.setOnClickListener{
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }



        btnIniciarSesion.setOnClickListener {
            val email= emailEditText.text.toString()
            val pass= claveEditText.text.toString()

            if (usuarioEsCorrecto(email,pass)) {
                val intent= Intent(this, PantallaPrincipal::class.java)
                val editor = sharedPreferences.edit()
                editor.putBoolean("recordar_usuario", checkBoxRecordarUsuario.isChecked)
                editor.putString("Usuario", emailEditText.text.toString())
                editor.putString("Clave" , claveEditText.text.toString())
                editor.apply()
                startActivity(intent);
                finish()
            } else {
                Toast.makeText(this, "Clave y/o Contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun usuarioEsCorrecto(email:String,clave:String):Boolean{
        val usuarioDao = dbUsuarios.usuariosDao()
        val usuario = usuarioDao.buscarUsuarioPorEmail(email)
        return usuario!= null && usuario.clave == clave
    }

}


